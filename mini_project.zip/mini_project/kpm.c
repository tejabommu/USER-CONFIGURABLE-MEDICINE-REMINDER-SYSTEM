//kpm.c
#include <lpc21xx.h>
#include "defines.h"
/* ===== KEYPAD ===== */
char keypad[4][4] =
{
    {'1','2','3','4'},
    {'5','6','7','8'},
    {'9','0','*','#'},
    {'A','B','C','D'}
};

void keypad_init()
{
    IODIR1 |= (0xF<<16);
    IODIR1 &= ~(0xF<<20);
    IOSET1 = (0xF<<16);
}

char keypad_scan()
{
    unsigned int r,c;

    while(1)
    {
        for(r=0;r<4;r++)
        {
            IOSET1 = (0xF<<16);
            IOCLR1 = (1<<(16+r));
            delay_ms(5);

            if(!(IOPIN1&(1<<20))) c=0;
            else if(!(IOPIN1&(1<<21))) c=1;
            else if(!(IOPIN1&(1<<22))) c=2;
            else if(!(IOPIN1&(1<<23))) c=3;
            else continue;

            while(!(IOPIN1&(1<<(20+c))));
            delay_ms(20);

            return keypad[r][c];
        }
    }
}


int readnum()
{
int num=0;
char key;
while(1){
        key = keypad_scan();
        if(key>='0' && key<='9')
        {
            num = (num*10) + (key-'0');
            LCD_Data(key);
        }
        else break;
                }
                return num;

}

