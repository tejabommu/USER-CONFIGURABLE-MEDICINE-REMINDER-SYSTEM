#include <lpc21xx.h>
#include "defines.h"

/* -------- GLOBAL VARIABLES -------- */

int hour,min,sec;
int date,month,year,day;

int menu_request = 0;

/* medicine timings */

int med1_hour=0, med1_min=1;
int med2_hour=13, med2_min=0;
int med3_hour=20, med3_min=0;



/* -------- RTC EDIT MENU -------- */

void edit_rtc()
{
char key;


LCD_Command(0x01);
LCD_String("1Hr 2Min 3Sec ");
        LCD_Command(0xC0);
LCD_String("4DT 5MON 6YR 7DY");

key = keypad_scan();
switch(key)
{
    case '1':
			hr:     LCD_Command(0x01);
		LCD_String("12Hr format (0-12)");
        LCD_Command(0xC0);
				LCD_String("New Hour:");
        hour = readnum();
		if(hour>0 && hour<13){
        HOUR = hour;
			 LCD_Command(0x01);
			LCD_String("updated sucessfully");
			delay_ms(500);
		}
		else{ 
			LCD_Command(0x01);
        LCD_String("HOUR Range(0-12)");
			delay_ms(500);
			goto hr;
	}
        break;

    case '2':
      min:  LCD_Command(0x01);
		LCD_String("MINUTE (0-60)");
            LCD_Command(0xC0);
            LCD_String("New Min:");
        min = readnum();
		if(min>0 && min<60){
			MIN=min;
			LCD_Command(0x01);
		LCD_String("updated sucessfully");
			delay_ms(500);
	}else{ 
			LCD_Command(0x01);
        LCD_String("MIN Range(0-60)");
		delay_ms(500);
		goto min;
	}
        break;

    case '3':
			sec:       LCD_Command(0x01);
		LCD_String("SECOND (0-60)");
           LCD_Command(0xC0);
          LCD_String("New Sec:");         
        sec = readnum();
		if(sec>0 && sec<60){
        SEC = sec;
			LCD_Command(0x01);
        LCD_String("updated sucessfully");
			delay_ms(500);
		}
		else {
			LCD_Command(0x01);
        LCD_String("SEC Range(0-60)");
			delay_ms(500);
			goto sec;
		}
        break;

    case '4':
			date:    LCD_Command(0x01);
		LCD_String("CURRENT-DATE(0-30)");
                LCD_Command(0xC0);
                LCD_String("New date:");
		        date=readnum();
		if(date>0 && date<32){ 
			DOM = date;
		LCD_Command(0x01);
        LCD_String("updated sucessfully");
			delay_ms(500);
	}
		else{
			LCD_Command(0x01);
        LCD_String("DATE Range(0-30)");
			delay_ms(500);
		goto date;
		}
        break;

    case '5':
			mon:    LCD_Command(0x01);
		LCD_String("CURRENT-MONTH(0-12)");
              LCD_Command(0xC0);
              LCD_String("New Month:");  
       month=readnum();
		if(month>0 && month <13){
		  MONTH = month;
		LCD_Command(0x01);
        LCD_String("updated sucessfully");
			delay_ms(500);
	}
		else {
			LCD_Command(0x01);
        LCD_String("MONTH Range(0-12)");
			delay_ms(500);
			goto mon;
		}
        break;

    case '6':
      yr:  LCD_Command(0x01);
		LCD_String("YEAR(2000-Pt)");
         LCD_Command(0xC0);
        LCD_String("New YEAR:");         
        year=readnum();
		if(year>2000 && year<2027){
			  YEAR =year; 
			LCD_Command(0x01);
        LCD_String("updated sucessfully");
			delay_ms(500);
		}
		else{
			LCD_Command(0x01);
        LCD_String("YEAR Range(2000-Pt)");
			delay_ms(500);
			goto yr;
		}
        break;
		case '7':
			day:	LCD_Command(0x01);
		LCD_String("0-Sun 1-Mon 2-Tue");
		delay_ms(500);
			LCD_Command(0x01);
		LCD_String("3-Wed 4-Thu 5-Fri");
		delay_ms(500);
			LCD_Command(0x01);
		LCD_String("6-Sat");
		LCD_Command(0xC0);
		LCD_String("DAY:");         
        day=readnum();
		if(day>0 && day<8){
			  DOW=day; 
			LCD_Command(0x01);
        LCD_String("updated sucessfully");
			delay_ms(500);
		}
		else{
			LCD_Command(0x01);
        LCD_String("DAY Range(1-6)");
			delay_ms(500);
			goto day;
		}
		
				
		
			
}
LCD_Command(0x01);


}

/* -------- MEDICINE EDIT MENU -------- */

void edit_medicine()
{
char key;
int h,m;


LCD_Command(0x01);
LCD_String("1-Med1 2-Med2");
	delay_ms(500);
			LCD_Command(0x01);
		LCD_String("3-Med3");

key = keypad_scan();

	h:LCD_Command(0x01);
	LCD_String("12Hr format (0-12)");
   LCD_Command(0xC0);
LCD_String("Hour:");
h = readnum();
	if(!(h>0 && h<13))
		goto h;

	m:LCD_Command(0x01);
		LCD_String("MINUTE (0-60)");
  LCD_Command(0xC0);LCD_Command(0xC0);
LCD_String("Min(0-60):");
m = readnum();
	if(!(m>0 && m<60))
		goto m;

if(key=='1')
{
    med1_hour=h;
    med1_min=m;
}

if(key=='2')
{
    med2_hour=h;
    med2_min=m;
}

if(key=='3')
{
    med3_hour=h;
    med3_min=m;
}

LCD_Command(0x01);


}

/* -------- MENU -------- */

void menu()
{
char key;


LCD_Command(0x01);
LCD_String("------MENU------");

LCD_Command(0xC0);
LCD_String("1-RTC edit ");
delay_ms(300);
LCD_Command(0xC0);
LCD_String("2-medicine edit");

key = keypad_scan();

if(key=='1')
    edit_rtc();

if(key=='2')
    edit_medicine();

LCD_Command(0x01);


}

/* -------- MAIN -------- */

int main()
{
int buzzer_time;


LCD_Init();
RTC_Init();
keypad_init();
buzzer_init();
interrupt_init();
//GetRTCDateInfo(&date,&month,&year);
//DisplayRTCDate(date, month, year);
while(1)
{
    /* display RTC */
    GetRTCTimeInfo(&hour,&min,&sec);
    DisplayRTCTime(hour,min,sec);
          GetRTCDateInfo(&date,&month,&year);
    DisplayRTCDate(date, month, year);

    /* medicine check */

    /* display RTC */
    GetRTCTimeInfo(&hour,&min,&sec);
    DisplayRTCTime(hour,min,sec);
	  GetRTCDay(&day);
    DisplayRTCDay(day);

    /* medicine check */

    if(hour==med1_hour && min==med1_min && sec==0)
    {
       IOSET0 = (1<<BUZZER_PIN);
        buzzer_time=0;

        while(buzzer_time<60)
        {
                if(((IOPIN0>>BUZZER_PIN)&1)==0)
                        break;
            delay_ms(1000);
            buzzer_time++;
        }


        IOCLR0 = (1<<BUZZER_PIN);
    }

    if(hour==med2_hour && min==med2_min && sec==0)
    {
       IOSET0 = (1<<BUZZER_PIN);
        buzzer_time=0;

        while(buzzer_time<60)
        {
                if(((IOPIN0>>BUZZER_PIN)&1)==0)
                        break;
            delay_ms(1000);
            buzzer_time++;
        }


        IOCLR0 = (1<<BUZZER_PIN);
    }

    if(hour==med3_hour && min==med3_min && sec==0)
    {
        IOSET0 = (1<<BUZZER_PIN);
        buzzer_time=0;

        while(buzzer_time<60)
        {
                if(((IOPIN0>>BUZZER_PIN)&1)==0)
                        break;
            delay_ms(1000);
            buzzer_time++;
        }


        IOCLR0 = (1<<BUZZER_PIN);
    }


    /* if interrupt requested menu */

    if(menu_request==1)
    {
        menu_request=0;
        menu();
    }
}



}

