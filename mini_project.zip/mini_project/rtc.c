//rtc.c
#include <lpc21xx.h>

//include LCD header files
//#include "lcd.h"
//#include "lcd_defines.h"

// System clock and peripheral clock Macros
#define FOSC 12000000
#define CCLK (5*FOSC)
#define PCLK (CCLK/4)

// RTC Prescaler Calculation Macros
// RTC requires 32.768 kHz clock for 1-second increment.
// PREINT and PREFRAC registers divide PCLK to generate 32.768 kHz.

// PREINT = int (PCLK / 32768) - 1;
// PREFRAC = PCLK -((PREINT + 1) * 32768);
// Note: This information collected from LPC2129 Manual

#define PREINT_VAL (int) ((PCLK / 32768) - 1)
#define PREFRAC_VAL (PCLK -((PREINT_VAL + 1) * 32768))

//RTC Control Register (CCR) Bit Definitions
// Bit 0 <96> Clock Enable --> 1 = Enable RTC counters  0 = Disable RTC counters
#define RTC_ENABLE (1<<0)

// Bit 1 <96> Clock Reset --> 1 = Reset RTC counters    0 = Normal operation
#define RTC_RESET (1<<1)


//only for LPC2148
// Bit 4 <96> Clock Source Select
// 1 = Use external 32.768 kHz oscillator
// 0 = Use internal PCLK as RTC clock source
#define RTC_CLKSRC (1<<4)

void LCD_Command(unsigned char cmd);
void LCD_Data(unsigned char data);
void LCD_Init(void);
void LCD_Char(char ch);
void LCD_String(char *str);

#define SUN 0
#define MON 1
#define TUE 2
#define WED 3
#define THU 4
#define FRI 5
#define SAT 6

void RTC_Init(void);
void GetRTCTimeInfo(int *,int *,int *);
void DisplayRTCTime(int,int,int);
void GetRTCDateInfo(int *,int *,int *);
void DisplayRTCDate(int,int,int);

void SetRTCTimeInfo(int,int,int);
void SetRTCDateInfo(int,int,int);

void GetRTCDay(int *);
void DisplayRTCDay(int);
void SetRTCDay(int);

//int hour,min,sec,date,month,year,day;

// Array to hold names of days of the week
char week[][4] = {"SUN","MON","TUE","WED","THU","FRI","SAT"};
char month_name[][4] =
{"JAN","FEB","MAR","APR","MAY","JUN",
 "JUL","AUG","SEP","OCT","NOV","DEC"};

#define _LPC2148

// Main function
/*int main()
{
    // Initialize RTC
                RTC_Init();
    // Initialize the LCD
                LCD_Init();

    // Set the initial time (hours, minutes, seconds)
                SetRTCTimeInfo(14,50,00);
    // Set the initial data (date, month, year)
                SetRTCDateInfo(2,3,2026);
    // Set initial day (SUN to SAT )
                SetRTCDay(MON);

    while (1)
    {
        // Get and display the current time info on LCD
                                GetRTCTimeInfo(&hour,&min,&sec);
                                DisplayRTCTime(hour,min,sec);
                                // Get and display the current date info on LCD
                                GetRTCDateInfo(&date,&month,&year);
                                DisplayRTCDate(date,month,year);
                                // Get and display the current day info on LCD
                                GetRTCDay(&day);
                                DisplayRTCDay(day);

    }
}
  */
/*
Initialize the Real-Time Clock (RTC)
This function disables the RTC, sets the prescaler values,
and then enables the RTC.
*/
void RTC_Init(void)
{
  // Disable and reset the RTC
        CCR = RTC_RESET;

        #ifndef _LPC2148

  // Set prescaler integer and fractional parts
        PREINT = PREINT_VAL;
        PREFRAC = PREFRAC_VAL;

  // Enable the RTC
        CCR = RTC_ENABLE;

        #else
  // Enable the RTC with external clock source
        CCR = RTC_ENABLE | RTC_CLKSRC;
        #endif
}

/*
Get the current RTC time
hour Pointer to store the current hour
minute Pointer to store the current minute
second Pointer to store the current second
*/
void GetRTCTimeInfo(int *hour, int *minute, int *second)
{
        *hour = HOUR;
        *minute = MIN;
        *second = SEC;
}

/*
Display the RTC time on LCD
hour value (0-23)
minute value (0-59)
second value (0-59) seperated by ':'
*/
void DisplayRTCTime(int hour, int minute, int second)
{
        LCD_Command(0x80);
        LCD_Char(hour/10+48);
        LCD_Char(hour%10+48);
        LCD_Char(':');
        LCD_Char(minute/10+48);
        LCD_Char(minute%10+48);
       // LCD_Char(':');
        //LCD_Char(second/10+48);
        //LCD_Char(second%10+48);
}

/*
Get the current RTC date
day Pointer to store the current date (1-31)
month Pointer to store the current month (1-12)
year Pointer to store the current year (four digits)
*/
void GetRTCDateInfo(int *date, int *month, int *year)
{
        *date = DOM;
        *month = MONTH;
        *year = YEAR;
}

/*
Display the RTC date on LCD
Day of month (1-31)
Month (1-12)
Year (four digits) and seperated by '/'
*/
void DisplayRTCDate(int date, int month, int year)
{
	LCD_Char(',');
        LCD_Command(0xC0+4);//to clear the screen
	


LCD_String(month_name[month-1]);
LCD_Char(' ');
        //CmdLCD(GOTO_LINE2_POS0);
        LCD_Char(date/10+48);
        LCD_Char(date%10+48);
        
        LCD_Char(' ');
        LCD_Char((year/1000)+48);
        LCD_Char(((year/100)%10)+48);
        LCD_Char(((year/10)%10)+48);
        LCD_Char(year%10+48);


}

/*
Set the RTC time
Hour to set (0-23)
Minute to set (0-59)
Second to set (0-59)
*/
void SetRTCTimeInfo(int hour, int minute, int second)
{
        HOUR = hour;
        MIN = minute;
        SEC = second;
}

/*
Set the RTC date
day of month to set (1-31)
month to set (1-12)
year to set (four digits)
*/
void SetRTCDateInfo(int date, int month, int year)
{
        DOM = date;
        MONTH = month;
        YEAR = year;
}

/*
Get the current day of the week
dow Pointer to store Day of Week (0=Sunday, ..., 6=Saturday)
*/
void GetRTCDay(int *dow)
{
        *dow = DOW;
}

/*
Display the current day of the week on LCD
dow (Day of Week) (0=Sunday, ..., 6=Saturday)
*/
void DisplayRTCDay(int dow)
{
        LCD_Command(0xC0);
        LCD_String(week[dow]);

}

/*
Set the day of the week in RTC
Day of Week to set (0=Sunday, ..., 6=Saturday)
*/
void SetRTCDay(int dow)
{
        DOW = dow;
}

