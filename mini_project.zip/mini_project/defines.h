//defines.h
#ifndef DEFINES_H
#define DEFINES_H

#include <lpc21xx.h>

/* -------- BUZZER PIN -------- */
#define BUZZER_PIN 17

/* -------- GLOBAL FLAGS -------- */
extern int menu_request;

/* -------- LCD FUNCTIONS -------- */
void LCD_Init(void);
void LCD_Command(unsigned char);
void LCD_Data(unsigned char);
void LCD_String(char *);
void LCD_Char(char);
void lcd_print(long);

/* -------- KEYPAD -------- */
void keypad_init(void);
char keypad_scan(void);
int readnum(void);

/* -------- RTC -------- */
void RTC_Init(void);
void GetRTCTimeInfo(int *,int *,int *);
void DisplayRTCTime(int,int,int);
void GetRTCDateInfo(int *,int *,int *);
void DisplayRTCDate(int,int,int);
void GetRTCDay(int *);
void DisplayRTCDay(int);
void SetRTCDay(int);

/* -------- BUZZER -------- */
void buzzer_init(void);
void buzzer_on(void);
void buzzer_off(void);

/* -------- INTERRUPTS -------- */
void interrupt_init(void);

/* -------- DELAY -------- */
void delay_ms(unsigned int);

#endif
