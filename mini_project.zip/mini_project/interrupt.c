//interrupt.c
#include <LPC21xx.h>
#include "defines.h"


//* Simple delay /
void delay(unsigned int d)
{
    unsigned int i,j;
    for(i=0;i<d;i++)
        for(j=0;j<6000;j++);
}

// EINT0 ISR /
void eint0_isr(void) __irq
{
    menu_request=1;

    EXTINT = 0x01;          // Clear EINT0 flag
    VICVectAddr = 0;
}

// EINT1 ISR /
void eint1_isr(void) __irq
{
   buzzer_off();     

    EXTINT = 0x02;          // Clear EINT1 flag
    VICVectAddr = 0;
}    

void interrupt_init()
{
    //* -------- Pin Function Select -------- /
    PINSEL1 |= 0x15400001;  // P0.16 -> EINT0
    PINSEL0 |= 0x20000000;  // P0.14 -> EINT1



   // /* -------- VIC Configuration -------- /

    // EINT0
        VICIntEnable |= (1<<14);
    VICVectCntl0 = (1<<5) | 14;
    //VICIntSelect = 0x00000000;
    VICVectAddr0 = (unsigned int)eint0_isr;
  //  VICVectCntl0 = 0x20 | 16;
    VICIntEnable|= (1<<15);

    // EINT1
   VICVectCntl1 = (1<<5) | 15;
    VICVectAddr1 = (unsigned int)eint1_isr;
//  VICVectCntl1 = 0x20 | 14;
   //VICIntEnable |= (1<<14);
 //* -------- Interrupt Mode -------- /
        EXTMODE = 0x03;      // Edge sensitive
    EXTPOLAR = 0x00;     // Falling edge
    
}



