.\buzzer.o: ..\buzzer.c
.\buzzer.o: C:\Keil\ARM\Inc\Philips\lpc21xx.h
.\buzzer.o: ..\defines.h
