//lcd.c  
	#include <lpc21xx.h>
   #define RS 20
   #define RW 19
   #define EN 21
   #define DATA 4

/* -------------------- Delay -------------------- */
void delay_ms(unsigned int ms)
{
    unsigned int i,j;
    for(i=0;i<ms;i++)
        for(j=0;j<10000;j++);
}

/* -------------------- LCD Command -------------------- */

void LCD_Command(unsigned char cmd)
{
    IOCLR0 = (1<<RS);        // RS = 0
    IOCLR0 = (1<<RW);        // RW = 0

    IOCLR0 = 0xFF<<DATA;        // Clear data pins
    IOSET0 = cmd<<DATA;         // Send command

    IOSET0 = (1<<EN);        // EN = 1
    delay_ms(2);
    IOCLR0 = (1<<EN);        // EN = 0
}

/* -------------------- LCD Data -------------------- */
void LCD_Data(unsigned char data)
{
    IOSET0 = (1<<RS);        // RS = 1
    IOCLR0 = (1<<RW);        // RW = 0

    IOCLR0 = 0xFF<<DATA;
    IOSET0 = data<<DATA;

    IOSET0 = (1<<EN);
    delay_ms(2);
    IOCLR0 = (1<<EN);
}

/* -------------------- LCD Init -------------------- */
void LCD_Init(void)
{
    IODIR0 |= 0xFF<<DATA;       // Data pins output
    IODIR0 |= (1<<RS)|(1<<RW)|(1<<EN);

    delay_ms(20);

    LCD_Command(0x38);       // 8-bit, 2 line
    LCD_Command(0x0C);       // Display ON
    LCD_Command(0x01);       // Clear
    LCD_Command(0x06);       // Entry mode
}

/* -------------------- Display Character -------------------- */
void LCD_Char(char ch)
{
    LCD_Data(ch);
}

/* -------------------- Display String -------------------- */
void LCD_String(char *str)
{
    while(*str)
        LCD_Data(*str++);
}

  /* ===== PRINT NUMBER ===== */
void lcd_print(long n)
{
    char buf[16];
    int i=0,j;

    if(n==0)
    {
        LCD_Data('0');
        return;
    }

    if(n<0)
    {
        LCD_Data('-');
        n=-n;
    }

    while(n>0)
    {
        buf[i++] = (n%10)+'0';
        n/=10;
    }
    for(j=i-1;j>=0;j--)
		LCD_Data(buf[j]);
}

