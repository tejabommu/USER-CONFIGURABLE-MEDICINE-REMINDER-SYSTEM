.\rtc.o: ..\rtc.c
.\rtc.o: C:\Keil\ARM\Inc\Philips\lpc21xx.h
