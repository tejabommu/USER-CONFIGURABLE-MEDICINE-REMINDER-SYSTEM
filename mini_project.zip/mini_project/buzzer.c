//buzzer.c
#include <lpc21xx.h>
#include "defines.h"

void buzzer_init()
{
IODIR0 |= (1<<BUZZER_PIN);
IOCLR0 = (1<<BUZZER_PIN);
}

void buzzer_on()
{
IOSET0 = (1<<BUZZER_PIN);
}

void buzzer_off()
{
IOCLR0 = (1<<BUZZER_PIN);
}
