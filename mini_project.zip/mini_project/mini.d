.\mini.o: ..\mini.c
.\mini.o: C:\Keil\ARM\Inc\Philips\lpc21xx.h
.\mini.o: ..\defines.h
